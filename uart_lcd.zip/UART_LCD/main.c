/*
 * main.c
 *
 *  Created on: 2016 Oct 24 12:50:35
 *  Author: Conti_02
 */

#include <DAVE.h>                 //Declarations from DAVE Code Generation (includes SFR declaration)
#include "LCDCommands.h"
/**

 * @brief main() - Application entry point
 *
 * <b>Details of function</b><br>
 * This routine is the application entry point. It is invoked by the device startup code. It is responsible for
 * invoking the APP initialization dispatcher routine - DAVE_Init() and hosting the place-holder for user application
 * code.
 */

int main(void) {
	DAVE_STATUS_t status;
	uint8_t inputString[1];
	char text;

	status = DAVE_Init(); /* Initialization of DAVE APPs  */

	if (status != DAVE_STATUS_SUCCESS) {
		/* Placeholder for error handler code. The while loop below can be replaced with an user error handler. */
		XMC_DEBUG("DAVE APPs initialization failed\n");

		while (1U) {

		}
	}
	begin(16, 2, LCD_5x8DOTS);
	clear();
	printString("Test");
	delayMicroseconds(1000000);
	while (1) {

		//Receive 10 bytes of data
		if (UART_Receive(&UART_0, inputString, 1) == UART_STATUS_SUCCESS) {
			text = inputString[0];

			if (text == 127)
				clear();
			if (text == 13){
				setCursor(0, 1);
			}
			if(text != 13 && text != 127)prints(text);
		}

	}

}
