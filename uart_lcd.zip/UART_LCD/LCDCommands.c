/*
 * LCDCommands.c
 *
 *  Created on: Oct 24, 2016
 *      Author: Conti_02
 */

#include <DAVE.h>
#include "LCDCommands.h"

uint8_t displayfunction;
uint8_t displaycontrol;
uint8_t displaymode;
uint8_t numlines;
uint8_t row_offsets[4];

// functions for LCD1602

void delay(long unsigned int i) {
	while (i--) {
		__NOP();
	}
}

/* Delay for the given number of microseconds.  Assumes a 8 or 16 MHz clock. */
void delayMicroseconds( uint32_t us )
{
    while (us--)
    {
        __ASM(" NOP\n\t"
        " NOP\n\t"
        " NOP\n\t"
        " NOP\n\t"
        " NOP\n\t"
        " NOP\n\t"
        " NOP\n\t"
        " NOP\n\t"
        " NOP\n\t"
        " NOP\n\t"
        " NOP\n\t");
    };
}


void begin(uint8_t cols, uint8_t lines, uint8_t dotsize) {
	dotsize = LCD_5x8DOTS;
	if (lines > 1) {
		displayfunction |= LCD_2LINE;
	}
	numlines = lines;

	setRowOffsets(0x00, 0x40, 0x00 + cols, 0x40 + cols);

	// rw pin here

	delay(500000);
	if (!(displayfunction & LCD_8BITMODE)) {
		write4bits(0x03);
		delayMicroseconds(45000);
		write4bits(0x03);
		delayMicroseconds(45000);
		write4bits(0x03);
		delayMicroseconds(1500);
		write4bits(0x02);
	} else {
		command(LCD_FUNCTIONSET | displayfunction);
		delayMicroseconds(45000);
		command(LCD_FUNCTIONSET | displayfunction);
		delayMicroseconds(1500);
		command(LCD_FUNCTIONSET | displayfunction);
	}
	command(LCD_FUNCTIONSET | displayfunction);

	displaycontrol = LCD_DISPLAYON | LCD_CURSOROFF | LCD_BLINKOFF;
	display();

	clear();

	displaymode = LCD_ENTRYLEFT | LCD_ENTRYSHIFTDECREMENT;

	command(LCD_ENTRYMODESET | displaymode);
}

void setRowOffsets(int row0, int row1, int row2, int row3) {
	row_offsets[0] = row0;
	row_offsets[1] = row1;
	row_offsets[2] = row2;
	row_offsets[3] = row3;
}

void clear() {
	command(LCD_CLEARDISPLAY);
	delayMicroseconds(20000);
}

void home() {
	command(LCD_RETURNHOME);
	delayMicroseconds(20000);
}

// commands for sending data/cmds

void command(uint8_t value) {
	send(value, 0);
}

void send(uint8_t value, uint8_t mode) {
	if (mode == 0) {
		DIGITAL_IO_SetOutputLow(&RS_PIN);
	}
	if (mode == 1)
		DIGITAL_IO_SetOutputHigh(&RS_PIN);
	if (displayfunction & LCD_8BITMODE) {
		//write8bits(value);
	} else {
		write4bits(value >> 4);
		write4bits(value);
	}
}

void pulseEnable(void) {
	DIGITAL_IO_SetOutputLow(&ENABLE_PIN);
	delayMicroseconds(10);
	DIGITAL_IO_SetOutputHigh(&ENABLE_PIN);
	delayMicroseconds(10);
	DIGITAL_IO_SetOutputLow(&ENABLE_PIN);
	delayMicroseconds(1000);
}

void write4bits(uint8_t value) {
	if (((value >> 0) & 0x01) == 1)
		DIGITAL_IO_SetOutputHigh(&D0_PIN);
	if (((value >> 0) & 0x01) == 0)
		DIGITAL_IO_SetOutputLow(&D0_PIN);

	if (((value >> 1) & 0x01) == 1)
		DIGITAL_IO_SetOutputHigh(&D1_PIN);
	if (((value >> 1) & 0x01) == 0)
		DIGITAL_IO_SetOutputLow(&D1_PIN);

	if (((value >> 2) & 0x01) == 1)
		DIGITAL_IO_SetOutputHigh(&D2_PIN);
	if (((value >> 2) & 0x01) == 0)
		DIGITAL_IO_SetOutputLow(&D2_PIN);

	if (((value >> 3) & 0x01) == 1)
		DIGITAL_IO_SetOutputHigh(&D3_PIN);
	if (((value >> 3) & 0x01) == 0)
		DIGITAL_IO_SetOutputLow(&D3_PIN);

	pulseEnable();
}

void scrollDisplayLeft() {
	command(LCD_CURSORSHIFT | LCD_DISPLAYMOVE | LCD_MOVELEFT);
}

void setCursor(uint8_t col, uint8_t row) {
	command(LCD_SETDDRAMADDR | (col + row_offsets[row]));
}

void prints(uint8_t value) {
	send(value, 1);
}

void printString(char *value){
	for(uint8_t i = 0; i < strlen(value); i++){
			prints(value[i]);
		}
}


void display() {
	displaycontrol |= LCD_DISPLAYON;
	command(LCD_DISPLAYCONTROL | displaycontrol);
}

void cursor(){
	displaycontrol |= LCD_CURSORON;
	command(LCD_DISPLAYCONTROL | displaycontrol);
}


