/*
 * main.c
 *
 *  Created on: 2016 Oct 17 09:58:33
 *  Author: Conti_02
 */

#include <DAVE.h>                 //Declarations from DAVE Code Generation (includes SFR declaration)

/**

 * @brief main() - Application entry point
 *
 * <b>Details of function</b><br>
 * This routine is the application entry point. It is invoked by the device startup code. It is responsible for
 * invoking the APP initialization dispatcher routine - DAVE_Init() and hosting the place-holder for user application
 * code.
 */

#define MIN_LIMIT 0x01
#define MAX_LIMIT 0x40

void delay(long unsigned int i);
void updateInput(uint8_t input[]);
void updateMatrix(uint8_t input[]);

uint8_t POS_HORIZONTAL= 0x01;
uint8_t POS_VERTICAL = 0x01;

int main(void) {
	DAVE_STATUS_t status;
	uint8_t inputArray[4];

	status = DAVE_Init(); /* Initialization of DAVE APPs  */

	if (status != DAVE_STATUS_SUCCESS) {
		/* Placeholder for error handler code. The while loop below can be replaced with an user error handler. */
		XMC_DEBUG("DAVE APPs initialization failed\n");

		while (1U) {

		}
	}

	/* Placeholder for user application code. The while loop below can be replaced with user application code. */
	while (1U) {

		updateInput(inputArray);
		updateMatrix(inputArray);
	}
}

void delay(long unsigned int i) {
	while (i--) {
		__NOP();
	}
}

void updateInput(uint8_t input[]) {
	input[0] = DIGITAL_IO_GetInput(&BUTTON_LEFT);
	input[1] = DIGITAL_IO_GetInput(&BUTTON_UP);
	input[2] = DIGITAL_IO_GetInput(&BUTTON_DOWN);
	input[3] = DIGITAL_IO_GetInput(&BUTTON_RIGHT);
}

void updateMatrix(uint8_t input[]) {

	DIGITAL_IO_SetOutputLow(&STORAGE);

	for (uint8_t i = 0; i < 8; i++) {
		if (!!(POS_HORIZONTAL & (1 << (7 - i))) == 1)
			DIGITAL_IO_SetOutputHigh(&DATA);
		if (!!(POS_HORIZONTAL & (1 << (7 - i))) == 0)
			DIGITAL_IO_SetOutputLow(&DATA);
		DIGITAL_IO_SetOutputHigh(&SHIFT);
		DIGITAL_IO_SetOutputLow(&SHIFT);
	}

	for (uint8_t i = 0; i < 8; i++) {
		if (!!(POS_VERTICAL & (1 << (7 - i))) == 1)
			DIGITAL_IO_SetOutputLow(&DATA);
		if (!!(POS_VERTICAL & (1 << (7 - i))) == 0)
			DIGITAL_IO_SetOutputHigh(&DATA);
		DIGITAL_IO_SetOutputHigh(&SHIFT);
		DIGITAL_IO_SetOutputLow(&SHIFT);
	}

	if (input[0] == 1) {
		if (POS_HORIZONTAL >= MIN_LIMIT && POS_HORIZONTAL <= MAX_LIMIT)
			POS_HORIZONTAL = POS_HORIZONTAL << 1;
	}
	if (input[3] == 1) {
		if (POS_HORIZONTAL > MIN_LIMIT && POS_HORIZONTAL <= (MAX_LIMIT << 1))
			POS_HORIZONTAL = POS_HORIZONTAL >> 1;
	}

	if (input[1] == 1) {
		if (POS_VERTICAL >= MIN_LIMIT && POS_VERTICAL <= MAX_LIMIT)
			POS_VERTICAL = POS_VERTICAL << 1;
	}
	if (input[2] == 1) {
		if (POS_VERTICAL > MIN_LIMIT && POS_VERTICAL <= (MAX_LIMIT << 1))
			POS_VERTICAL = POS_VERTICAL >> 1;
	}

	DIGITAL_IO_SetOutputHigh(&STORAGE);
	delay(300000);
}



