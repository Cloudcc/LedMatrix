/*
 * main.c
 *
 *  Created on: 2016 Sep 26 21:46:20
 *  Author: Johnny
 */

#include <DAVE.h>                 //Declarations from DAVE Code Generation (includes SFR declaration)

/**

 * @brief main() - Application entry point
 *
 * <b>Details of function</b><br>
 * This routine is the application entry point. It is invoked by the device startup code. It is responsible for
 * invoking the APP initialization dispatcher routine - DAVE_Init() and hosting the place-holder for user application
 * code.
 */

#define LM75_ADDRESS_W 				 0b10010000
#define LM75_ADDRESS_R 				 0b10010001
#define LM75_TEMP_REGISTER 			 0b00000000
#define LM75_CONFIG_REGISTER         0b00000001
#define LM75_THYST_REGISTER          0b00000010
#define LM75_TOS_REGISTER            0b00000011

int main(void) {
	// SCL = P0.8  SDA = P0.6
	uint32_t index = 0;
	uint16_t data;
	int8_t temp[1];
	uint8_t trigger[1] = "0";

	DAVE_STATUS_t status;

	status = DAVE_Init(); /* Initialization of DAVE APPs  */

	if (status != DAVE_STATUS_SUCCESS) {
		/* Placeholder for error handler code. The while loop below can be replaced with an user error handler. */
		XMC_DEBUG("DAVE APPs initialization failed\n");

		while (1U) {

		}
	}
	while (1U) {
		if (UART_Receive(&UART_0, trigger, 1) == UART_STATUS_SUCCESS) {

			if (trigger[0] == '1') {
				I2C_MASTER_SendStart(&I2C_MASTER_0, 0x90,
						XMC_I2C_CH_CMD_WRITE);
				while (I2C_MASTER_GetFlagStatus(&I2C_MASTER_0,
						XMC_I2C_CH_STATUS_FLAG_ACK_RECEIVED) == 0U) {
					// wait for ACK
				}
				I2C_MASTER_ClearFlag(&I2C_MASTER_0,
						XMC_I2C_CH_STATUS_FLAG_ACK_RECEIVED);
				// write to address 0
				I2C_MASTER_TransmitByte(&I2C_MASTER_0, 0x00);
				while (I2C_MASTER_GetFlagStatus(&I2C_MASTER_0,
						XMC_I2C_CH_STATUS_FLAG_ACK_RECEIVED) == 0U) {
					// wait for ACK
				}
				I2C_MASTER_ClearFlag(&I2C_MASTER_0,
						XMC_I2C_CH_STATUS_FLAG_ACK_RECEIVED);
				I2C_MASTER_SendRepeatedStart(&I2C_MASTER_0, 0x90,
						XMC_I2C_CH_CMD_READ);
				while (I2C_MASTER_GetFlagStatus(&I2C_MASTER_0,
						XMC_I2C_CH_STATUS_FLAG_ACK_RECEIVED) == 0U) {
					// wait for ACK
				}
				I2C_MASTER_ClearFlag(&I2C_MASTER_0,
						XMC_I2C_CH_STATUS_FLAG_ACK_RECEIVED);
				while (index < 16) {
					I2C_MASTER_ReceiveACK(&I2C_MASTER_0);
					index++;
				}
				// only for the last byte
				I2C_MASTER_ReceiveNACK(&I2C_MASTER_0);
				//Wait when Rx FIFO is empty
				while (!I2C_MASTER_IsRXFIFOEmpty(&I2C_MASTER_0)) {
					data = I2C_MASTER_GetReceivedByte(
							&I2C_MASTER_0);
					//data<<1;
				}
				temp[0] = data;
				UART_Transmit(&UART_0, temp, 1);

				I2C_MASTER_SendStop(&I2C_MASTER_0);
				// UART output to console
			}
		}
	}

	return 1U;
}
