/*
 * main.c
 *
 *  Created on: 2016 Sep 15 21:00:42
 *  Author: Johnny
 */

#include <DAVE.h>                 //Declarations from DAVE Code Generation (includes SFR declaration)

/**

 * @brief main() - Application entry point
 *
 * <b>Details of function</b><br>
 * This routine is the application entry point. It is invoked by the device startup code. It is responsible for
 * invoking the APP initialization dispatcher routine - DAVE_Init() and hosting the place-holder for user application
 * code.
 */

void draw_screen(uint8_t data[]);
void say_hallo(uint8_t data[]);

void delay(uint32_t t) {
	for (uint32_t i = 0; i < t; i++)
		;
}

int main(void) {
	DAVE_STATUS_t status;
	UART_STATUS_t init_status;
	uint8_t trigger[1];
	uint8_t msg[] = "Running...";

	uint8_t test1[] = { 0x7E, 0x3C, 0xA5, 0xC3, 0xC3, 0xA5, 0x3C, 0x7E, };
	uint8_t test2[] = { 0x3C, 0x7E, 0xE7, 0xDB, 0xDB, 0xE7, 0x7E, 0x3C, };
	uint8_t test3[] = { 0xC3, 0xBD, 0x76, 0x5A, 0x5A, 0x76, 0xBD, 0xC3, };
	uint8_t
	hallo[] = {0xFF, 0xFF,
		0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,0xFF, 0x81, 0xEF, 0xEF, 0xEF, 0xEF, 0x81, 0xFF, 0xFF,
		0xFF, 0xC1, 0xB7, 0xB7, 0xC1, 0xFF, 0xFF, 0xFF, 0xFF, 0x81, 0xFD,
		0xFD, 0xFD, 0xFF, 0xFF, 0xFF, 0xFF, 0x81, 0xFD, 0xFD, 0xFD, 0xFF,
		0xFF, 0xFF, 0xFF, 0xC3, 0xBD, 0xBD, 0xC3, 0xFF, 0xFF, 0xFF, 0xFF,
		0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
	};



	status = DAVE_Init(); /* Initialization of DAVE APPs  */

	if (status != DAVE_STATUS_SUCCESS) {
		/* Placeholder for error handler code. The while loop below can be replaced with an user error handler. */
		XMC_DEBUG("DAVE APPs initialization failed\n");

		while (1U) {

		}
	}
	// Set Pins to Low
	DIGITAL_IO_SetOutputLow(&DIGITAL_IO_0);	// shift 	SH_CP 6
	DIGITAL_IO_SetOutputLow(&DIGITAL_IO_1);	// storage 	ST_CP 7
	DIGITAL_IO_SetOutputLow(&DIGITAL_IO_2);	// data		DS 8

	// init UART
	init_status = (UART_STATUS_t) UART_Init(&UART_0);
	if (init_status == UART_STATUS_SUCCESS) {
		UART_Transmit(&UART_0, msg, sizeof(msg) - 1);
		while (1) {
			if (UART_Receive(&UART_0, trigger, 1) == UART_STATUS_SUCCESS) {
				if (trigger[0] == '1') {
					UART_Transmit(&UART_0, msg, sizeof(msg) - 1);
					while (trigger[0] == '1') {
						draw_screen(test1);
						UART_Receive(&UART_0, trigger, 1);
					}
				}
				if (trigger[0] == '2') {
					while (trigger[0] == '2') {
						draw_screen(test2);
						UART_Receive(&UART_0, trigger, 1);
					}
				}
				if (trigger[0] == '3') {
					while (trigger[0] == '3') {
						draw_screen(test3);
						UART_Receive(&UART_0, trigger, 1);
					}
				}
				if (trigger[0] == '4') {
					while (trigger[0] == '4') {
						say_hallo(hallo);
						UART_Receive(&UART_0, trigger, 1);
					}
				}

			}
		}
	} else {
		XMC_DEBUG("Application initialization failed");
		while (1U) {
		}
	}
	return 1U;
}

void say_hallo(uint8_t data[]) {
	for (uint8_t i = 0; i < 48; i++) {
		for (uint8_t t = 0; t < 10; t++) {
			uint8_t dat = 0x01;
			for (uint8_t num = i; num < 8 + i; num++) {

				for (uint8_t i = 0; i < 8; i++) {

					if (!!(data[num] & (1 << (7 - i))) == 1) DIGITAL_IO_SetOutputLow(
							&DIGITAL_IO_2);
					if (!!(data[num] & (1 << (7 - i))) == 0) DIGITAL_IO_SetOutputHigh(
							&DIGITAL_IO_2);
					DIGITAL_IO_SetOutputHigh(&DIGITAL_IO_0);
					DIGITAL_IO_SetOutputLow(&DIGITAL_IO_0);
				}
				for (uint8_t i = 0; i < 8; i++) {
					if (!!(dat & (1 << (7 - i))) == 1) DIGITAL_IO_SetOutputLow(
							&DIGITAL_IO_2);
					if (!!(dat & (1 << (7 - i))) == 0) DIGITAL_IO_SetOutputHigh(
							&DIGITAL_IO_2);
					DIGITAL_IO_SetOutputHigh(&DIGITAL_IO_0);
					DIGITAL_IO_SetOutputLow(&DIGITAL_IO_0);

				}
				DIGITAL_IO_SetOutputHigh(&DIGITAL_IO_1);
				DIGITAL_IO_SetOutputLow(&DIGITAL_IO_1);
				dat = dat << 1;
				delay(1000);

			}
		}
	}
}

void draw_screen(uint8_t data[]) {
	uint8_t dat = 0x01;
	for (uint8_t k = 0; k < 8; k++) {
		for (uint8_t i = 0; i < 8; i++) {

			if (!!(data[k] & (1 << (7 - i))) == 1) DIGITAL_IO_SetOutputLow(
					&DIGITAL_IO_2);
			if (!!(data[k] & (1 << (7 - i))) == 0) DIGITAL_IO_SetOutputHigh(
					&DIGITAL_IO_2);
			DIGITAL_IO_SetOutputHigh(&DIGITAL_IO_0);
			DIGITAL_IO_SetOutputLow(&DIGITAL_IO_0);
		}
		for (uint8_t i = 0; i < 8; i++) {
			if (!!(dat & (1 << (7 - i))) == 1) DIGITAL_IO_SetOutputLow(
					&DIGITAL_IO_2);
			if (!!(dat & (1 << (7 - i))) == 0) DIGITAL_IO_SetOutputHigh(
					&DIGITAL_IO_2);
			DIGITAL_IO_SetOutputHigh(&DIGITAL_IO_0);
			DIGITAL_IO_SetOutputLow(&DIGITAL_IO_0);

		}
		DIGITAL_IO_SetOutputHigh(&DIGITAL_IO_1);
		DIGITAL_IO_SetOutputLow(&DIGITAL_IO_1);
		dat = dat << 1;
		delay(100);
	}
}
