/*
 * main.c
 *
 *  Created on: 2016 Oct 10 10:17:57
 *  Author: Conti_02
 */

#include <DAVE.h>                 //Declarations from DAVE Code Generation (includes SFR declaration)

/**

 * @brief main() - Application entry point
 *
 * <b>Details of function</b><br>
 * This routine is the application entry point. It is invoked by the device startup code. It is responsible for
 * invoking the APP initialization dispatcher routine - DAVE_Init() and hosting the place-holder for user application
 * code.
 */

void delay(uint32_t time);

int main(void) {
	DAVE_STATUS_t status;
	uint8_t index[4] = { 0, 1, 2, 3 };
	uint32_t toggleLeft;
	uint32_t toggleRight;
	int8_t i = 0;

	status = DAVE_Init(); /* Initialization of DAVE APPs  */

	if (status != DAVE_STATUS_SUCCESS) {
		/* Placeholder for error handler code. The while loop below can be replaced with an user error handler. */
		XMC_DEBUG("DAVE APPs initialization failed\n");

		while (1U) {

		}
	}
	DIGITAL_IO_SetOutputHigh(&LED_0);
	DIGITAL_IO_SetOutputLow(&LED_1);
	DIGITAL_IO_SetOutputLow(&LED_2);
	DIGITAL_IO_SetOutputLow(&LED_3);
for(uint8_t = 0; i < 4; i++){

}
	/* Placeholder for user application code. The while loop below can be replaced with user application code. */
	while (1U) {
		toggleLeft = DIGITAL_IO_GetInput(&LEFT);
		toggleRight = DIGITAL_IO_GetInput(&RIGHT);
		if (toggleRight == 1 && toggleLeft == 0) {
			i++;
			if (i > 3)
				i = 0;
			switch (index[i]) {
			case 0:
				DIGITAL_IO_SetOutputHigh(&LED_0);
				DIGITAL_IO_SetOutputLow(&LED_1);
				DIGITAL_IO_SetOutputLow(&LED_2);
				DIGITAL_IO_SetOutputLow(&LED_3);
				break;
			case 1:
				DIGITAL_IO_SetOutputLow(&LED_0);
				DIGITAL_IO_SetOutputHigh(&LED_1);
				DIGITAL_IO_SetOutputLow(&LED_2);
				DIGITAL_IO_SetOutputLow(&LED_3);
				break;
			case 2:
				DIGITAL_IO_SetOutputLow(&LED_0);
				DIGITAL_IO_SetOutputLow(&LED_1);
				DIGITAL_IO_SetOutputHigh(&LED_2);
				DIGITAL_IO_SetOutputLow(&LED_3);
				break;
			case 3:
				DIGITAL_IO_SetOutputLow(&LED_0);
				DIGITAL_IO_SetOutputLow(&LED_1);
				DIGITAL_IO_SetOutputLow(&LED_2);
				DIGITAL_IO_SetOutputHigh(&LED_3);
				break;

			}
			delay(500000);
			toggleRight = 0;
			toggleLeft = 0;
		}
		else if (toggleRight == 0 && toggleLeft == 1) {
			i--;
			if (i < 0)
				i = 3;
			switch (index[i]) {
			case 0:
				DIGITAL_IO_SetOutputHigh(&LED_0);
				DIGITAL_IO_SetOutputLow(&LED_1);
				DIGITAL_IO_SetOutputLow(&LED_2);
				DIGITAL_IO_SetOutputLow(&LED_3);
				break;
			case 1:
				DIGITAL_IO_SetOutputLow(&LED_0);
				DIGITAL_IO_SetOutputHigh(&LED_1);
				DIGITAL_IO_SetOutputLow(&LED_2);
				DIGITAL_IO_SetOutputLow(&LED_3);
				break;
			case 2:
				DIGITAL_IO_SetOutputLow(&LED_0);
				DIGITAL_IO_SetOutputLow(&LED_1);
				DIGITAL_IO_SetOutputHigh(&LED_2);
				DIGITAL_IO_SetOutputLow(&LED_3);
				break;
			case 3:
				DIGITAL_IO_SetOutputLow(&LED_0);
				DIGITAL_IO_SetOutputLow(&LED_1);
				DIGITAL_IO_SetOutputLow(&LED_2);
				DIGITAL_IO_SetOutputHigh(&LED_3);
				break;

			}
			delay(500000);
			toggleLeft = 0;
			toggleRight = 0;
		}
	}
}

void delay(uint32_t time) {
	for (uint32_t i = 0; i < time; i++)
		;
}

